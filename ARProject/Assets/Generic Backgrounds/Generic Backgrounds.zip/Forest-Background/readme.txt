This background is sliced out as separate .png files to create a parallax effect. A flattened version is also included.

1920 x 1080px
72 dpi
.PNG files included

(Please note, this background is not repeatable.)