SD Kohaku-Chanz! OPV(Optimize, Parting,Variation)


Character License : Unity Technologies Japan (http://unity-chan.com)
Edit Develop : Studio Haon (http://rugiadian.wix.com/Haon-info)
Parts info spreadsheet : https://docs.google.com/spreadsheets/d/1tssAmgsX2qNTXeCIJPFwRhcHuqWMuvzz5l2tlrqOHGw/edit?usp=sharing


This graphic asset is provide optimized and utilized version of "SD unity-chan" and "SD Kohaku-Chanz" which serviced by unity technology japan.

We provide spreadsheet which shows names of meshs and textures at the top of this document

There are two types of model mesh, one is character and costume binded model and the other is partially divided model.
Each are in folder name ��model/Model-part�� and ��model/model-set��.
Provided prefab have two types. Models that is set-models have ��Set_�� in front of name.

- 1.5 ver
Male style character 'Hotaru' has been added.
This character is Haon's original character that is irrelevant to 'Unity Chan'.
But 'Hotaru' is created by applying 'Uni-chan' source, so Uni-chan license is applied.




�� UTJ/UCL

